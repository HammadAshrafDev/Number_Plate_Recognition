# car_license_plate > 2021-09-01 12:06pm
https://universe.roboflow.com/matheus-santos-almeida/car_license_plate

Provided by a Roboflow user
License: Public Domain

